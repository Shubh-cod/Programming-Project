How to run the code?
To run the code follow the steps :-
1.As the given file is in zipped format first step is to extract those files.

2.Then open the python file 'Programming_assignment.py 'in a python compliler (vscode is preferred)

3.Before starting make sure to install general libraries pandas,numpy and matplotlib.pyplot

4.The above can be done in cmd prompt by using code "pip install pandas , pip install numpy,pip install matplotlib.pyplot" 

5.Go to the folder where you have extracted the zip file and find 'data.csv' file.

6.Right click and go to properties.

7.In properties under general section copy the location from there.

8.Now paste this code in pd.read_csv("file loaction")

9.Location Format will be like-: location_copied\data.csv (for example_:C:/Users/DELL/Desktop/data.csv)

10.Run the code

11.First graph will popup the shown graph is the comparison graph between x1[n] and x[n]

12.Close that graph tab to find second graph between x2[n] and x[n]
   
***Precaution-:generally file location contain '\' but to import we have to use '/'***

